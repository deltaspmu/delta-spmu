exports.handler = async (event) => {
  return {
    statusCode: 200,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "https://admin.deltaspmu.com",
      "Access-Control-Allow-Headers": "Content-Type,Authorization,X-Api-Key",
      "Access-Control-Allow-Methods": "GET,POST,PATCH,DELETE,OPTIONS"
    },
    body: JSON.stringify({ message: "Placeholder — deploy real handler" })
  };
};
